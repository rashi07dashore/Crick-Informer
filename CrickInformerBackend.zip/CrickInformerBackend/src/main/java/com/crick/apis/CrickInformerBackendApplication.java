package com.crick.apis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrickInformerBackendApplication {

	public static void main(String[] args) {

		SpringApplication.run(CrickInformerBackendApplication.class, args);
	}

}
